# Identificador M.Schuenker

Sistema inteligente para identificação de peças industriais como parafusos, porcas e arruelas.

## Rodar local

```bash
npm install
npm run dev
```

## Deploy

1. Suba para o GitHub
2. Importe para o Vercel: https://vercel.com/import