import { siteConfig } from "../../site.config";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      <header className="text-center py-12 bg-gradient-to-b from-blue-900 to-blue-700 text-white">
        <h1 className="text-5xl font-bold tracking-tight">{siteConfig.nomeMarca}</h1>
        <p className="mt-3 text-lg font-light">{siteConfig.descricao}</p>
        <p className="text-sm mt-1 opacity-70">{siteConfig.subtitulo}</p>
      </header>

      <main className="max-w-5xl mx-auto p-6 grid gap-8">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Demonstração</h2>
          <p className="mb-4">Clique abaixo para testar o sistema:</p>
          <a href={siteConfig.linkProtótipo} target="_blank" rel="noopener noreferrer">
            <button className="bg-blue-700 text-white px-6 py-3 rounded hover:bg-blue-800">
              Acessar Protótipo
            </button>
          </a>
        </section>
      </main>

      <footer className="text-center py-6 text-xs text-gray-400">
        &copy; {new Date().getFullYear()} {siteConfig.nomeMarca}. Todos os direitos reservados.
      </footer>
    </div>
  );
}