export const siteConfig = {
  nomeMarca: "M.Schuenker",
  descricao: "Identificador Inteligente de Peças Industriais",
  subtitulo: "Soluções precisas para manutenção, organização e economia",
  linkProtótipo: "https://identificador.mschuenker.app",
  emailContato: "contato@mschuenker.com.br",
  mensagemConvite: "Quer se juntar à revolução da manutenção inteligente?",
  parceiros: ["CAT", "Volvo", "New Holland"],
};